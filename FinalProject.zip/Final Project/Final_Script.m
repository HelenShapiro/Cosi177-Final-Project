
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

file = 'ax_fast.txt'; %Insert name of file with amino chains here
time=5; %Specify Range of Divergence Times to Test

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


D=load('pis_diag.dat');
A=load('ratemat.dat');
molclock=0.5 ;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% D=pis_diag; %EF Matrix
% A=ratemat; %Rate Matrix

[v,u]=readafile(file);
%Set v for first string
%set u for second string
%Converts amino string to number sequence
% v1=amino2number(v);
% u1=amino2number(u);


t=0.000:.01:time;
%Calculates Log-likelihood function and plots it
L=Likelihood(v,u,A,D,t);
plot(t,L)
title('Expected Divergence Time')
xlabel('Expected Substitutions Per Unit of Time')
ylabel('Log-Likelihood')
[maxvalue, maxindex]=max(L);
MLDT=t(maxindex)/(molclock*length(u)) ; 

fprintf('MLDT: %f mutations per site per unit time.\n      This is approximately %f b.y.a.\n',t(maxindex),MLDT) ;

