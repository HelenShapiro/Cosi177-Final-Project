function [u,v]=readafile(fname) 
% reads a file with two amino acid sequences, each on their own lines, into vectors
% appropriate for Likelihood.m


file=fopen(fname) ; 
asciis=fread(file) ; 

read1=0;
j=1; 
for i=1:length(asciis)

     
    switch asciis(i)
            case {65    97}   % a
                u(j)=1 ; 
            case {67    99}   % c
                u(j)=5 ; 
            case {68    100}   % d
                u(j)=4 ; 
            case {69    101}   % e
                u(j)=7 ; 
            case {70    102}   % f
                u(j)=14 ; 
            case {71    103}   % g
                u(j)=8 ; 
            case {72    104}   % h
                u(j)=9 ; 
            case {73    105}   % i
                u(j)=11 ; 
            case {75    107}   % k
                u(j)=12 ; 
            case {76    108}   % l
                u(j)=10 ; 
            case {77    109}   % m  
                u(j)=13 ; 
            case {78    110}   % n 
                u(j)=3 ; 
            case {80    112}   % p 
                u(j)=15 ; 
            case {81    113}   % q 
                u(j)=6 ; 
            case {82    114}   % r 
                u(j)=2 ; 
            case {83    115}   % s 
                u(j)=16 ; 
            case {84    116}   % t 
                u(j)=17 ; 
            case {86    118}   % v 
                u(j)=20 ; 
            case {87    119}   % w 
                u(j)=18 ; 
            case {89    121}   % y 
                u(j)=19 ; 
            case {10}
                if (read1==0)
                    v=u ; 
                    read1=1;
                    j = 0 ; 
                else
                end
                
                
            end

        j = j + 1 ; 

end

end
    
