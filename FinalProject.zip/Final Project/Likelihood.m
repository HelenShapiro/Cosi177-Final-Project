function L=Likelihood(v,u,A,D,t)
format long
L=zeros(1,length(t));
if (length(u)==length(v))
for i=1:length(t)           % i represents the time
    P=expm(A*t(i));
    for j=1:length(u)       % j represents the index of a sequence
        Terms(j)=0 ;
        for k=1:20          % k represents the possible amino acid at the root
            Terms(j)= Terms(j) + P(v(j),k)*P(u(j),k)*D(k,k) ; 
        end
    end
L(1,i)=sum(log((Terms)));
end
else
    fprintf('ERROR ERROR ERROR')
end
